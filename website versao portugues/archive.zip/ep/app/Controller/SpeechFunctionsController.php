<?php
App::uses('AppController', 'Controller');
/**
 * SpeechFunctions Controller
 *
 * @property SpeechFunction $SpeechFunction
 * @property PaginatorComponent $Paginator
 */
class SpeechFunctionsController extends AppController {


}
